const Hoster = require('./src/Manager/class/Hoster')
new Hoster()

process.on('unhandledRejection', (reason, promise) => {
  if ([10062].includes(reason.code)) return
  console.log(promise, reason);
});