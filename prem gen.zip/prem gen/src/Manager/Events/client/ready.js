const { ActivityType, Events } = require('discord.js');
const Hoster = require("../../class/Hoster");

module.exports = {
  name: Events.ClientReady,

  /**
   * @param {Hoster} host
   */
  async run(host) {
    console.log(`[Manager] ${host.user.tag} is ready`);
    host.user.setStatus('dnd');
    host.user.setActivity("discord.gg/galaxygen", { type: ActivityType.Streaming, url: "https://twitch.tv/wqtz" });
    host.loadSlashCmds(host);

  }
};