const fs = require('node:fs').promises;
const Discord = require('discord.js')
module.exports = {
    name: 'premium_gen',
    description: 'Generate an account',
    category: 'Mod',
    options: [
        {
            name: 'name',
            description: 'The category.',
            type: "string",
            required: true,
            autocomplete: true
        }
    ],

    /**
     * 
     * @param {*} client 
     * @param {Discord.CommandInteraction} interaction 
     */

    async run(client, interaction) {
        const categoryName = interaction.options.getString('name');
        const filePath = `./src/Manager/stock/${categoryName}`;
        const fileContent = await fs.readFile(filePath, 'utf-8');

        const accounts = fileContent.trim().split('\n');
        
        if (accounts.length === 0 || !accounts) {
            await interaction.reply({ content: 'The account list is empty.', ephemeral: true });
            return;
        }
        const randomAccountIndex = Math.floor(Math.random() * accounts.length);
        const randomAccount = accounts[randomAccountIndex];
        accounts.splice(randomAccountIndex, 1);

        if (!randomAccount) return interaction.reply({content: "There are no more accounts in stock.", ephemeral: true})

        await fs.writeFile(filePath, accounts.join('\n'));
        await interaction.user.send(`**Thank you for using GALAXYGEN <:galaxygen:1241822395694710784>!**\n > Here is your account: \`${randomAccount}\``);
        await interaction.reply({ embeds: [new Discord.EmbedBuilder().setDescription('<a:1224393120297254923:1241823218457776168> **Your account has been successfully generated! check your private message.**').setFooter({iconURL:'https://cdn.discordapp.com/attachments/1242127821195972680/1242152529413013534/e8b081eec36cf88c907031fae10596f5.png?ex=664ccc31&is=664b7ab1&hm=8194029cfd58d934e6ee96fa1bdea8f4e02aba0030c52d5794ddebe8133443e4&',text:'GALAXYGEN | discord.gg/galaxygen'}).setTitle('GALAXYGEN').setImage('https://cdn.discordapp.com/attachments/1242127821195972680/1242152198243352576/standard_3.gif?ex=664ccbe2&is=664b7a62&hm=52972336a39f330d72b49a754e54d74da27c3b30aad9094e7f1a77f66792beb1&').setTimestamp().setColor('#8F00FF')], ephemeral: false });
    },
};