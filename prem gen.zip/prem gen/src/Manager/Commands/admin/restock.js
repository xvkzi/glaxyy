const axios = require('axios')
const fs = require('node:fs').promises;

module.exports = {
    name: 'rspr',
    description: '[ADMIN] Restock account of a category.',
    category: 'Mod',
    admin: true,
    options: [
        {
            name: 'name',
            description: 'La catégorie.',
            type: "string",
            required: true,
            autocomplete: true
        },
        {
            name: 'lien',
            description: 'Le lien past.ee contenant les comptes à restocker.',
            type: "string",
            required: true
        }
    ],

    /**
     * 
     * @param {*} client 
     * @param {Discord.CommandInteraction} interaction 
     */

    async run(client, interaction) {
        const categoryName = interaction.options.getString('name');
        const lien = interaction.options.getString('lien');
        const code = lien.replace("https://paste.ee/p/", "");
        try {
            let stockToAdd = '';
            const filePath = `./src/Manager/stock/${categoryName}`;
            const fileExists = await fs.access(filePath).then(() => true).catch(() => false);
            if (fileExists) {
                stockToAdd = await fs.readFile(filePath, 'utf-8');
            }

            const response = await axios.get(`https://paste.ee/d/${code}`, {
                headers: {
                    "User-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/102.0.5005.61 Safari/537.36"
                }
            });

            stockToAdd += '\n' + response.data ;

            await fs.writeFile(filePath, stockToAdd, { flag: 'w' }); 

            await interaction.reply({ content: 'Les comptes ont été restockés avec succès.', ephemeral: true });
        } catch (error) {
            console.log(error)
            await interaction.reply({ content: 'Une erreur s\'est produite lors du restock des comptes.', ephemeral: true });
        }
    },
};