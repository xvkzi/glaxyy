const { Client, Collection, Routes, SlashCommandBuilder } = require("discord.js")
const { REST } = require("@discordjs/rest")
const fs = require("node:fs")
const path = require('path')

module.exports = class Hoster extends Client {
    constructor() {
        super({
            intents: 3276799,
            partials: [
                1, 2, 3, 4,
                5, 6, 0
            ]
        });
        this.setMaxListeners(0);
        this.config = require('../../../config.json')
        this.staff = this.config.owner;
        this.cooldowntime = this.config.cooldown
        this.salon = this.config.salon;
        this.commands = new Collection();
        this.loadEvents();
        global.Hoster = this
        this.loadCommands();
        this.login(this.config.manager)
    }

    loadCommands() {
        for (const dir of fs.readdirSync("./src/Manager/Commands")) {
            for (const fileName of fs.readdirSync(`./src/Manager/Commands/${dir}`)) {
                const file = require(`../Commands/${dir}/${fileName}`);
                file.category = dir;
                this.commands.set(file.name, file)
                delete require.cache[require.resolve(`../Commands/${dir}/${fileName}`)]
            }
        }
    }

  

    loadEvents() {
        for (const dir of fs.readdirSync("./src/Manager/Events")) {
            for (const fileName of fs.readdirSync(`./src/Manager/Events/${dir}`)) {
                const file = require(`../Events/${dir}/${fileName}`);
                this.on(file.name, (...args) => file.run(this, ...args))
                delete require.cache[require.resolve(`../Events/${dir}/${fileName}`)]
            }
        }
    }


    async loadSlashCmds(client) {
        let commands = [];

        client.commands.forEach(async command => {

            let slashcommand = new SlashCommandBuilder()
                .setName(command.name)
                .setDescription(command.description)
                .setDMPermission(command.dm)
                .setDefaultMemberPermissions(command.permission === "Aucune" ? null : command.permission)

            if (command.options?.length >= 1) {
                for (let i = 0; i < command.options.length; i++) {
                    slashcommand[`add${command.options[i].type?.slice(0, 1).toUpperCase() + command.options[i].type?.slice(1) || ''}Option`](option => option.setName(command.options[i].name).setDescription(command.options[i].description).setRequired(command.options[i].required).setAutocomplete(command.options[i]?.autocomplete || false))
                }
            }
            await commands.push(slashcommand)
        })

        const rest = new REST({ version: "10" }).setToken(client.token)

        await rest.put(Routes.applicationCommands(client.user.id), { body: commands })
    }
}
