const fs = require('node:fs').promises;

module.exports = {
    name: 'deletepr',
    description: '[ADMIN] delete a category',
    category: 'Mod',
    admin: true,
    options: [
        {
            name: 'name',
            description: 'La catégorie.',
            type: "string",
            required: true,
            autocomplete: true
        },
    ],

    /**
     * 
     * @param {*} client 
     * @param {Discord.CommandInteraction} interaction 
     */

    async run(client, interaction) {
        const categoryName = interaction.options.getString('name');
        
        try {
            const fileExists = await fs.access(`./src/Manager/stock/${categoryName}`).then(() => true).catch(() => false);
            if (fileExists) {
                await fs.unlink(`./src/Manager/stock/${categoryName}`); 
                await interaction.reply({ content: `La catégorie ${categoryName} a été supprimée avec succès.`, ephemeral: true });
            } else {
                await interaction.reply({ content: `La catégorie "${categoryName}" n'existe pas.`, ephemeral: true });
            }
        } catch (error) {
            console.log(error)
            await interaction.reply({ content: 'Une erreur s\'est produite lors de la suppression de la catégorie.', ephemeral: true });
        }
    },
};