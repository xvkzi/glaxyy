const fs = require('node:fs').promises;

module.exports = {
    name: 'showpr',
    description: '[ADMIN ]Send the stock in .txt file.',
    category: 'Mod',
    admin: true,
    options: [
        {
            name: 'name',
            description: 'La catégorie.',
            type: "string",
            required: true,
            autocomplete: true
        }
    ],

    /**
     * 
     * @param {*} client 
     * @param {Discord.CommandInteraction} interaction 
     */

    async run(client, interaction) {
        const categoryName = interaction.options.getString('name');
        try {
            const filePath = `./src/Manager/stock/${categoryName}`;
            const fileExists = await fs.access(filePath).then(() => true).catch(() => false);
            if (fileExists) {
                const stockContent = await fs.readFile(filePath, 'utf-8');
                await interaction.reply({ files: [{ attachment: Buffer.from(stockContent), name: `${categoryName}` }], ephemeral: true });
            } else {
                await interaction.reply({ content: `Le fichier **${categoryName}** n'existe pas ou est vide.`, ephemeral: true });
            }
        } catch (error) {
            console.log(error);
            await interaction.reply({ content: 'Une erreur s\'est produite lors de la lecture du stock.', ephemeral: true });
        }
    },
};
