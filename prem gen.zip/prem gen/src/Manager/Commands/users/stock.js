const fs = require('node:fs').promises;
const Discord = require('discord.js');

module.exports = {
    name: 'premium_stock',
    description: 'Shows the number of accounts in each category.',
    category: 'Mod',

    /**
     * 
     * @param {*} client 
     * @param {Discord.CommandInteraction} interaction 
     */

    async run(client, interaction) {
        try {
            const stockDirectory = './src/Manager/stock';
            const stockFiles = await fs.readdir(stockDirectory);
            let stockDescription = '';

            for (const file of stockFiles) {
                const filePath = `${stockDirectory}/${file}`;
                const fileStats = await fs.stat(filePath);

                if (fileStats.isFile() && file.endsWith('.txt')) {
                    const fileContent = await fs.readFile(filePath, 'utf-8');
                    const accounts = fileContent.trim().split('\n');
                    const accountCount = accounts.filter(account => account.trim() !== '').length;
                    const categoryName = file.slice(0, -4);
                    stockDescription += `**${categoryName}**: \`${accountCount}\`\n`;
                }
            }

            await interaction.reply({ embeds: [{title: "**PREMIUM Account stock**", description: stockDescription}], ephemeral: false });
        } catch (error) {
            console.log(error);
            await interaction.reply({ content: 'Une erreur s\'est produite lors de la lecture du stock.', ephemeral: true });
        }
    },
};
