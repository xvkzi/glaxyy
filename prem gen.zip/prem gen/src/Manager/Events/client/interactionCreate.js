const { Events, InteractionType, Interaction, TextInputStyle, ModalBuilder, TextInputBuilder, ActionRowBuilder } = require('discord.js')
const Hoster = require("../../class/Hoster")
const fs = require("node:fs").promises
const cooldowns = new Map();

module.exports = {
    name: Events.InteractionCreate,

    /**
     * @param {Hoster} client
     * @param {Interaction} interaction
    */

    async run(client, interaction) {
        if (interaction.type === InteractionType.ApplicationCommand) {
            const command = client.commands.get(interaction.commandName);
            const isAdmin = client.staff.includes(interaction.user.id); 
            if (command.admin && !isAdmin) return interaction.reply({ content: '`❌` You cant use this command', flags: 64 })
            if (!client.salon.includes(interaction.channelId)) return interaction.reply({ content: '`❌` You cant use this command in this channel', flags: 64 })
    
            const cooldown = await cooldownCheck(interaction.commandName, interaction.user.id, isAdmin, client.cooldowntime);

            console.log(cooldown)

            if (cooldown) {
                return interaction.reply({ content: `<:check:1236330873935364166> Please wait ${cooldown.toFixed(1)} seconds before using this command.`, ephemeral: true });
            }
    
            command.run(client, interaction, interaction.options)
        }
        if (interaction.isAutocomplete()) {
            if (["premium_gen", "rspr", "showpr", "deletepr"].includes(interaction.commandName)) {
                const value = interaction.options.getFocused();

                const files = await fs.readdir("./src/Manager/stock/");

                const options = files.map(file => ({
                    name: file.replace('.txt', ""),
                    value: file,
                }));

                const filtered = options.filter(choice => choice.name.includes(value) || choice.value.startsWith(value));
                await interaction.respond(filtered.map(choice => ({ name: choice.name, value: choice.value })));
            }
        }
    }
}

async function cooldownCheck(commandName, userId, isAdmin, cooldownTime) {
    if (!cooldowns.has(commandName)) {
        cooldowns.set(commandName, new Map());
    }

    const now = Date.now();
    const timestamps = cooldowns.get(commandName);
    const cooldownAmount = cooldownTime * 1000;

    if (timestamps.has(userId)) {
        const expirationTime = timestamps.get(userId) + (isAdmin ? 0 : cooldownAmount);

        if (now < expirationTime) {
            const timeLeft = (expirationTime - now) / 1000;
            return timeLeft;
        }
    }

    timestamps.set(userId, now);
    setTimeout(() => timestamps.delete(userId), isAdmin ? 0 : cooldownAmount); 
    return false;
}